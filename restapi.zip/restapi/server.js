const express = require ('express');
const mongoose = require('mongoose');
const User = require('./models/user');
const app = express();
const router =  new express.Router();
app.use(express.json());
app.use('/api', router);
require ('dotenv').config();


//mongoose.connect('mongodb://localhost:27017/restapi',{})
mongoose.connect(`mongodb://${process.env.dbhost}:${process.env.dbport}/restapi`,
{
    useUnifiedTopology: true,
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
  })
.then(()=>console.log('mongodb connected....'))
.catch((err)=>console.log (err))

    const port =process.env.port  
    app.listen(port,()=>{
        console.log('server is in port'+  port)
    })

  router.post('/', async (req, res) => {
    
    const user = new User(req.body);
        console.log("------in post ",user)
       try {
            console.log(req.body)
            await user.save()
            res.status(201).send({user})
        } catch (e) {
    console.log("error",e) 
        }
    })
    router.get('/', async (req, res) => {
      
            try {
                const user = await User.find()
                if (!user) {
                    throw new Error()
                }
                res.send(user)
            } catch (e) {
                res.status(404).send()
            }
        })

        router.delete('/:id', async (req, res) => {
            try {
                const userFound = await User.findById({_id: req.params.id})
                console.log("userFound: ",userFound )
                if(!userFound){
                    res.status(404).json({
                        message: "Object with these information doesn't exist",
                        dsepostata: {}
                    })
                }
                await userFound.remove()
                res.status(200).json({
                    message: "Deleted successfully",
                    data: {}
                })
            } catch (e) {
                res.status(500).send()
            }
        })
        router.put('/', async (req, res) => {
    
            const user = new User(req.body);
                console.log("------in post ",user)
               try {
                    console.log(req.body)
                    await user.save()
                    res.status(201).send({user})
                } catch (e) {
            console.log("error",e) 
                }
            })