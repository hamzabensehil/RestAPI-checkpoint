const mongoose = require('mongoose')
const validator = require("validator")
const schema = mongoose.schema;


const userSchema = new mongoose.Schema({
    name : {
        type : String,
    required : true},
    password : {
        type : String},
    email : {
        type:String,
    unique:true,
lowercase:true,
validate(value){
    if (!validator.isEmail(value)){
        throw new error ('email is invalid')
    }
}
}

});
const user = mongoose.model('user',userSchema);
module.exports= user  